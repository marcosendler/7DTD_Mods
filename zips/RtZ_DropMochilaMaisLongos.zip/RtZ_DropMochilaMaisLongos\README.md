# RtZ Drop de Mochila mais Longos

## 7 Days 2 Die Modlet

Reduz a taxa de decadência das bolsas de saque de zumbis de 5 para 30 minutos